// Initialize Quill.js
var quill = new Quill('#editor', {
    theme: 'snow'
});

// Save button click event
$('#saveBtn').on('click', function () {
    var content = quill.root.innerHTML;
    $.ajax({
        url: 'save.php',
        method: 'POST',
        data: { content: content },
        success: function (response) {
            // Handle the response as needed
        }
    });
});

// Print content button click event
$('#printContentBtn').on('click', function () {
    // Create a new window for printing
    var printWindow = window.open('', '', 'width=600,height=600');

    // Add content to the new window
    printWindow.document.open();
    printWindow.document.write('<html><head><title>Print Content</title></head><body>');
    printWindow.document.write('<h1>Printed Content</h1>');
    printWindow.document.write('<div id="printArea">' + quill.root.innerHTML + '</div>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();

    // Trigger the print dialog
    printWindow.print();

    // Close the new window after printing
    printWindow.close();
});

// Fetch and display the content from the database
function fetchContent() {
    $.ajax({
        url: 'fetch.php',
        method: 'GET',
        success: function (response) {
            quill.root.innerHTML = response;
        }
    });
}

// Call the fetchContent function on page load
fetchContent();
